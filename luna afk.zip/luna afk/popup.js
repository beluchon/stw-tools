const toggle = document.getElementById('toggle');
const statusText = document.getElementById('status-text');

chrome.storage.local.get({ maskEnabled: true }, (data) => {
    toggle.checked = data.maskEnabled;
    updateText(data.maskEnabled);
});

toggle.addEventListener('change', () => {
    const isEnabled = toggle.checked;
    chrome.storage.local.set({ maskEnabled: isEnabled });
    updateText(isEnabled);
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0] && tabs[0].url && tabs[0].url.includes("luna.amazon")) {
            chrome.tabs.reload(tabs[0].id);
        }
    });
});

function updateText(isEnabled) {
    statusText.innerText = isEnabled ? "Masque Plein Écran : ON" : "Masque Plein Écran : OFF";
    statusText.style.color = isEnabled ? "#1dd15d" : "#ff4444";
}