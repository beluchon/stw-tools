chrome.storage.local.get({ maskEnabled: true }, (data) => {
    window.postMessage({ type: "LUNA_TOGGLE_MASK", isEnabled: data.maskEnabled }, "*");
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.maskEnabled !== undefined) {
        window.postMessage({ type: "LUNA_TOGGLE_MASK", isEnabled: changes.maskEnabled.newValue }, "*");
    }
});