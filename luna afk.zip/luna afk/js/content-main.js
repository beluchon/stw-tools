/**
 * LUNA ANTI-AFK PRO - VERSION ULTIME EXPANSION (ADAPTÉE)
 * Version optimisée avec ID spécifiques et redirection intelligente.
 */

(function() {
    console.log("%c Luna Anti-AFK Pro : Initialisation du moteur système...", "color: #ff9900; font-weight: bold; font-size: 14px;");

    // --- 1. CONFIGURATION ET CONSTANTES ---
    const CONFIG = {
        SCAN_INTERVAL: 1500,           // Intervalle du scanner (ms)
        REENTRY_DELAY: 6000,          // Attente après "Reprendre" pour le flux vidéo (ms)
        PAUSE_AFTER_CLICK: 5000,      // Blocage du scan après une action (ms)
        AFK_INTERVAL: 60000,          // Fréquence de la touche F15 (ms)
        // Identifiants spécifiques fournis par l'utilisateur
        ID_BOUTON_JOUER: "#item_primary_game_detail_button_game_session_async",
        ID_IMAGE_FORTNITE: '[data-test-id="FortniteBattleRoyale_image"]',
        ID_PRODUIT_FORTNITE: '[id*="6a64a0e0-814b-4208-a176-86120b103ad1"]',
        SEARCH_KEYWORDS: ["jouer", "play", "reprendre", "fortnite"],
        LOG_PREFIX: "color: #1dd15d; font-weight: bold;"
    };

    // --- 2. GESTION DU MASQUE PLEIN ÉCRAN ---
    const realFullscreen = Object.getOwnPropertyDescriptor(Document.prototype, 'fullscreenElement').get;
    const realWebkit = Object.getOwnPropertyDescriptor(Document.prototype, 'webkitFullscreenElement').get;
    window.lunaMaskEnabled = true;

    window.addEventListener("message", (event) => {
        if (event.source === window && event.data.type === "LUNA_TOGGLE_MASK") {
            window.lunaMaskEnabled = event.data.isEnabled;
            console.log(`%c [SYSTEM] Masque Plein Écran : ${window.lunaMaskEnabled ? 'ACTIF' : 'INACTIF'}`, "color: #3498db;");
        }
    });

    Object.defineProperty(Document.prototype, 'fullscreenElement', { get: function() { return window.lunaMaskEnabled ? document.documentElement : realFullscreen.call(this); } });
    Object.defineProperty(Document.prototype, 'webkitFullscreenElement', { get: function() { return window.lunaMaskEnabled ? document.documentElement : realWebkit.call(this); } });

    // --- 3. PROTECTION ANTI-DETECTION ---
    document.addEventListener('visibilitychange', (e) => e.stopImmediatePropagation(), true);
    window.addEventListener('blur', (e) => e.stopImmediatePropagation(), true);
    Object.defineProperty(Document.prototype, 'hidden', { get: () => false });
    Object.defineProperty(Document.prototype, 'visibilityState', { get: () => 'visible' });

    // --- 4. LOGIQUE DE RELANCE AUTOMATIQUE ---
    function demarrerRelanceAuto() {
        let pauseEnCours = false;

        function estVisible(element) {
            if (!element) return false;
            const rect = element.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0 && window.getComputedStyle(element).display !== 'none';
        }

        function simulerReentreeJeu() {
            console.log("%c [ACTION] Tentative de réentrée forcée...", CONFIG.LOG_PREFIX);
            window.focus();
            const cible = document.querySelector('video, canvas') || document.body;
            const options = { bubbles: true, cancelable: true, view: window, clientX: window.innerWidth / 2, clientY: window.innerHeight / 2, button: 0, buttons: 1 };
            cible.dispatchEvent(new MouseEvent('mousedown', options));
            setTimeout(() => {
                cible.dispatchEvent(new MouseEvent('mouseup', { ...options, buttons: 0 }));
                cible.click();
                cible.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
            }, 200);
        }

        function forcerClic(element, estReprise = false) {
            element.scrollIntoView({ block: "center", behavior: "smooth" });
            setTimeout(() => {
                const pDown = new PointerEvent('pointerdown', { bubbles: true, pointerId: 1, isPrimary: true, button: 0 });
                const pUp = new PointerEvent('pointerup', { bubbles: true, pointerId: 1, isPrimary: true, button: 0 });
                element.dispatchEvent(pDown);
                element.dispatchEvent(pUp);
                element.click();
                if (estReprise) setTimeout(simulerReentreeJeu, CONFIG.REENTRY_DELAY);
            }, 500); 
        }

        function scannerEcran() {
            if (pauseEnCours) return;

            // ÉTAPE 0 : GESTION D'ERREUR "PAGE NON TROUVÉE"
            if (document.body.innerText.includes("Impossible de trouver la page demandée")) {
                console.warn("[SYSTEM] Page introuvable détectée. Redirection vers l'accueil...");
                window.location.assign(window.location.origin + "/home");
                pauseEnCours = true;
                setTimeout(() => { pauseEnCours = false; }, 3000);
                return;
            }

            // ÉTAPE 1 : FERMER LES SUGGESTIONS
            const btnFermer = document.querySelector("#collection_post_game_dialog_game_suggestions-close-button");
            if (estVisible(btnFermer)) {
                forcerClic(btnFermer);
                pauseEnCours = true;
                setTimeout(() => { pauseEnCours = false; }, 2000); 
                return;
            }

            // ÉTAPE 2 : BOUTON "JOUER MAINTENANT" (VOTRE ID PRÉCIS)
            const btnJouerID = document.querySelector(CONFIG.ID_BOUTON_JOUER);
            if (estVisible(btnJouerID)) {
                console.log("%c [DETECT] Bouton de lancement ID détecté !", CONFIG.LOG_PREFIX);
                forcerClic(btnJouerID);
                pauseEnCours = true;
                setTimeout(() => { pauseEnCours = false; }, CONFIG.PAUSE_AFTER_CLICK); 
                return;
            }

            // ÉTAPE 3 : REPRENDRE / CONTINUER
            const btnReprendre = document.querySelector("#recover_button");
            const btnContinuer = document.querySelector("#item_current_session_takeover_button");
            const cibleSession = btnReprendre || btnContinuer;
            if (estVisible(cibleSession)) {
                forcerClic(cibleSession, (cibleSession === btnReprendre));
                pauseEnCours = true;
                setTimeout(() => { pauseEnCours = false; }, 10000);
                return;
            }

            // ÉTAPE 4 : SCANNER FORTNITE SUR L'ACCUEIL
            if (window.location.href.includes("/home") || window.location.href === window.location.origin + "/") {
                const fortniteTile = document.querySelector(CONFIG.ID_IMAGE_FORTNITE)?.closest('[role="button"]') || 
                                     document.querySelector(CONFIG.ID_PRODUIT_FORTNITE);
                if (fortniteTile && estVisible(fortniteTile)) {
                    console.log("%c [DETECT] Vignette Fortnite trouvée sur l'accueil !", CONFIG.LOG_PREFIX);
                    forcerClic(fortniteTile);
                    pauseEnCours = true;
                    setTimeout(() => { pauseEnCours = false; }, CONFIG.PAUSE_AFTER_CLICK);
                    return;
                }
            }
        }

        const observer = new MutationObserver(() => { if (!pauseEnCours) scannerEcran(); });
        observer.observe(document.body, { childList: true, subtree: true });
        setInterval(scannerEcran, CONFIG.SCAN_INTERVAL);
    }

    // --- 5. ANTI-AFK SYSTÈME (F15) ---
    function simulerActivite() {
        console.log("%c [AFK-SHIELD] Envoi signal F15...", "color: #7f8c8d;");
        const options = { key: 'F15', code: 'F15', keyCode: 126, bubbles: true, view: window };
        const cible = document.activeElement || window;
        cible.dispatchEvent(new KeyboardEvent('keydown', options));
        setTimeout(() => cible.dispatchEvent(new KeyboardEvent('keyup', options)), 50);
    }

    // --- 6. INITIALISATION ---
    if (document.readyState === 'complete' || document.readyState === 'interactive') { demarrerRelanceAuto(); } 
    else { window.addEventListener('load', demarrerRelanceAuto); }
    setInterval(simulerActivite, CONFIG.AFK_INTERVAL);

    // --- 7. RACCOURCIS CLAVIER ---
    document.addEventListener('keydown', (event) => {
        // ! : RECHARGER
        if (event.key === '!') window.location.reload();

        // * : LANCER FORTNITE (VIA ID)
        if (event.key === '*') {
            console.log("%c [ACTION] Raccourci '*' : Lancement ciblé de Fortnite...", CONFIG.LOG_PREFIX);
            const cible = document.querySelector(CONFIG.ID_IMAGE_FORTNITE)?.closest('[role="button"]') || 
                          document.querySelector(CONFIG.ID_PRODUIT_FORTNITE);
            if (cible) { cible.click(); } 
            else { window.location.assign(window.location.origin + "/home"); }
        }

        // + : MACRO ECHAP + CLIC (915, 229)
        if (event.key === '+') {
            console.log("%c [ACTION] Raccourci '+' : Macro Echap + Clic...", CONFIG.LOG_PREFIX);
            const cible = document.querySelector('video, canvas') || document.body;
            setTimeout(() => {
                cible.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
                setTimeout(() => {
                    const opts = { bubbles: true, clientX: 915, clientY: 229, button: 0, buttons: 1 };
                    cible.dispatchEvent(new MouseEvent('mousedown', opts));
                    setTimeout(() => {
                        cible.dispatchEvent(new MouseEvent('mouseup', { ...opts, buttons: 0 }));
                        cible.click();
                    }, 10);
                }, 2000);
            }, 2000);
        }
    });

    console.log("%c [READY] Luna Anti-AFK Pro (Expansion) est opérationnel.", "color: #1dd15d; border: 1px solid #1dd15d; padding: 2px;");
})();